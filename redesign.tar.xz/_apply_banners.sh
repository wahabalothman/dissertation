#!/usr/bin/env bash
set -e
B='_banner.txt'
for f in research/index.qmd theory/index.qmd theory/gap-summary.qmd theory/transmission-framework.qmd \
         design/index.qmd design/codebook.qmd design/sampling-rule.qmd design/falsification.qmd \
         data/index.qmd data/manifest.qmd data/coverage-log.qmd; do
  [ -f "$f" ] || continue
  grep -q "PLACEHOLDER" "$f" && continue
  awk -v b="$(cat $B)" 'BEGIN{n=0} {print} /^---$/{n++; if(n==2){print ""; print b}}' "$f" > "$f.tmp" && mv "$f.tmp" "$f"
  echo "banner: $f"
done
rm -f _banner.txt _apply_banners.sh
